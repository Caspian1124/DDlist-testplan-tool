from __future__ import annotations

import csv
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Sequence

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font

from app.models.part_models import ChangeListMatch, ReleaseNoteRow
from app.services.excel_testplan_builder import (
    build_no_inventory_table,
    build_release_note_table,
    build_system_fw_table,
    build_testplan_rows,
    build_version_note_table,
    infer_os_order,
)
from app.services.os_rule_engine import TestPlanRowState
from app.services.selection_engine import NoInventoryPart


def generate_output_filename(project_name: str, date_str: Optional[str] = None) -> str:
    if not date_str:
        date_str = datetime.now().strftime("%Y%m%d")
    return f"TestPlan1_{project_name}_{date_str}.xlsx"


class TestPlanExporter:
    def __init__(self, output_dir: str | Path = "output"):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def export_testplan_excel(self, project_name: str, row_states: Sequence[TestPlanRowState], no_inventory_parts: Sequence[NoInventoryPart], release_rows: Optional[Sequence[ReleaseNoteRow]] = None, system_fw_rows: Optional[Sequence[Dict[str, object]]] = None, version_note_lines: Optional[Sequence[str]] = None, date_str: Optional[str] = None) -> Path:
        filename = generate_output_filename(project_name, date_str)
        output_path = self.output_dir / filename
        wb = Workbook()
        main_ws = wb.active
        main_ws.title = "DDlist"
        os_order = infer_os_order(row_states)
        headers, rows = build_testplan_rows(row_states, os_order=os_order)
        self._write_sheet(main_ws, headers, rows)

        release_ws = wb.create_sheet(title="Release note")
        self._write_sheet(release_ws, *build_release_note_table(release_rows or []))

        system_fw_ws = wb.create_sheet(title="System FW")
        self._write_sheet(system_fw_ws, *build_system_fw_table(system_fw_rows or []))

        version_note_ws = wb.create_sheet(title="版本注释")
        self._write_sheet(version_note_ws, *build_version_note_table(version_note_lines or []))

        no_inventory_ws = wb.create_sheet(title="无库存部件")
        self._write_sheet(no_inventory_ws, *build_no_inventory_table(no_inventory_parts))

        wb.save(output_path)
        return output_path

    def export_change_list_reports(self, project_name: str, matches: Sequence[ChangeListMatch], date_str: Optional[str] = None) -> Dict[str, Path]:
        if not date_str:
            date_str = datetime.now().strftime("%Y%m%d")
        csv_path = self.output_dir / f"ChangeList_{project_name}_{date_str}.csv"
        txt_path = self.output_dir / f"ChangeList_{project_name}_{date_str}.txt"
        self._export_change_list_csv(csv_path, matches)
        self._export_change_list_txt(txt_path, matches)
        return {"csv": csv_path, "txt": txt_path}

    def _write_sheet(self, ws, headers: List[str], rows: List[List[object]]) -> None:
        ws.append(headers)
        for row in rows:
            ws.append(row)
        for cell in ws[1]:
            cell.font = Font(bold=True)
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        for row in ws.iter_rows(min_row=2):
            for cell in row:
                cell.alignment = Alignment(vertical="top", wrap_text=True)
        for col_cells in ws.columns:
            max_length = 0
            col_letter = col_cells[0].column_letter
            for cell in col_cells:
                value = "" if cell.value is None else str(cell.value)
                max_length = max(max_length, len(value))
            ws.column_dimensions[col_letter].width = min(max(max_length + 2, 12), 60)

    def _export_change_list_csv(self, path: Path, matches: Sequence[ChangeListMatch]) -> None:
        headers = ["release_date", "release_version", "extracted_pn", "exists_in_ddlist", "matched_ddlist_row_count", "status", "message"]
        with path.open("w", encoding="utf-8-sig", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(headers)
            for item in matches:
                writer.writerow([item.release_date, item.release_version, item.extracted_pn, item.exists_in_ddlist, item.matched_ddlist_row_count, item.status, item.message])

    def _export_change_list_txt(self, path: Path, matches: Sequence[ChangeListMatch]) -> None:
        with path.open("w", encoding="utf-8") as f:
            f.write("Change List 对比报告\n")
            f.write("=" * 80 + "\n")
            for item in matches:
                line = f"日期: {item.release_date} | 版本: {item.release_version} | PN: {item.extracted_pn} | 存在: {item.exists_in_ddlist} | 匹配数: {item.matched_ddlist_row_count} | 状态: {item.status} | 说明: {item.message}"
                f.write(line + "\n")

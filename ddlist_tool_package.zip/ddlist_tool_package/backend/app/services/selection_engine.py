from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence, Tuple

from app.models.part_models import DerivedPartFeatures, InventoryRecord, NormalizedPart


@dataclass
class PartCandidate:
    part: NormalizedPart
    features: DerivedPartFeatures
    inventory_status: str
    inventory_match_reason: str
    matched_inventory: Optional[InventoryRecord] = None


@dataclass
class NoInventoryPart:
    part: NormalizedPart
    features: DerivedPartFeatures
    reason: str
    suggestion: Optional[str] = None


@dataclass
class SelectionResult:
    selected_candidates: List[PartCandidate]
    no_inventory_parts: List[NoInventoryPart]
    rejected_candidates: List[PartCandidate]


class SelectionEngine:
    def __init__(self, inventory_records: Optional[Sequence[InventoryRecord]] = None):
        self.inventory_records = list(inventory_records or [])

    def select_parts(self, parts: Sequence[NormalizedPart], features_list: Sequence[DerivedPartFeatures]) -> SelectionResult:
        if len(parts) != len(features_list):
            raise ValueError("parts 与 features_list 长度不一致，无法进行选择")
        candidates = [self._build_candidate(part, features) for part, features in zip(parts, features_list)]

        selected: List[PartCandidate] = []
        no_inventory: List[NoInventoryPart] = []
        rejected: List[PartCandidate] = []

        hdd_ssd_candidates = [c for c in candidates if c.part.part_type.upper() in {"HDD", "SSD"}]
        nic_candidates = [c for c in candidates if c.part.part_type.upper() == "NIC"]
        raid_candidates = [c for c in candidates if c.part.part_type.upper() == "RAID"]

        hdd_selected, hdd_no_inv, hdd_rejected = self._select_hdd_ssd(hdd_ssd_candidates)
        nic_selected, nic_no_inv, nic_rejected = self._select_nic(nic_candidates)
        raid_selected, raid_no_inv, raid_rejected = self._select_raid(raid_candidates)

        selected.extend(hdd_selected)
        selected.extend(nic_selected)
        selected.extend(raid_selected)
        no_inventory.extend(hdd_no_inv)
        no_inventory.extend(nic_no_inv)
        no_inventory.extend(raid_no_inv)
        rejected.extend(hdd_rejected)
        rejected.extend(nic_rejected)
        rejected.extend(raid_rejected)

        return SelectionResult(selected_candidates=selected, no_inventory_parts=no_inventory, rejected_candidates=rejected)

    def _build_candidate(self, part: NormalizedPart, features: DerivedPartFeatures) -> PartCandidate:
        matched_inventory, reason = self._match_inventory(part, features)
        status = matched_inventory.inventory_status if matched_inventory else "无"
        return PartCandidate(part=part, features=features, inventory_status=status, inventory_match_reason=reason, matched_inventory=matched_inventory)

    def _match_inventory(self, part: NormalizedPart, features: DerivedPartFeatures) -> Tuple[Optional[InventoryRecord], str]:
        if not self.inventory_records:
            return None, "未提供库存文件"
        pn = (part.pn or "").strip().upper()
        vendor = (features.normalized_vendor or "").strip().lower()
        model = (features.normalized_model or "").strip().lower()
        spec = self._build_capacity_or_spec(features).strip().lower()
        pn_matches = [item for item in self.inventory_records if item.inventory_pn and item.inventory_pn.strip().upper() == pn]
        if pn_matches:
            return self._pick_best_inventory_record(pn_matches), "PN 精确匹配"
        vmc_matches = [item for item in self.inventory_records if item.inventory_vendor.strip().lower() == vendor and item.inventory_model.strip().lower() == model and item.inventory_capacity_or_spec.strip().lower() == spec]
        if vmc_matches:
            return self._pick_best_inventory_record(vmc_matches), "厂商+型号+容量/规格匹配"
        mc_matches = [item for item in self.inventory_records if item.inventory_model.strip().lower() == model and item.inventory_capacity_or_spec.strip().lower() == spec]
        if mc_matches:
            return self._pick_best_inventory_record(mc_matches), "型号+容量/规格匹配"
        m_matches = [item for item in self.inventory_records if item.inventory_model.strip().lower() == model]
        if m_matches:
            return self._pick_best_inventory_record(m_matches), "仅型号匹配"
        return None, "库存未匹配"

    @staticmethod
    def _pick_best_inventory_record(records: Sequence[InventoryRecord]) -> InventoryRecord:
        return sorted(records, key=lambda r: (1 if r.inventory_status == "有" else 0), reverse=True)[0]

    @staticmethod
    def _build_capacity_or_spec(features: DerivedPartFeatures) -> str:
        if features.capacity_value is not None and features.capacity_unit:
            value = int(features.capacity_value) if float(features.capacity_value).is_integer() else features.capacity_value
            return f"{value}{features.capacity_unit}"
        if features.raid_spec:
            return features.raid_spec
        if features.nic_port_count and features.nic_speed_gbps:
            return f"{features.nic_port_count}-port {features.nic_speed_gbps}GbE"
        if features.spec_value:
            return features.spec_value
        return ""

    def _select_hdd_ssd(self, candidates: Sequence[PartCandidate]) -> Tuple[List[PartCandidate], List[NoInventoryPart], List[PartCandidate]]:
        grouped: Dict[str, List[PartCandidate]] = {}
        for c in candidates:
            group_key = c.features.normalized_model or c.part.supplier_pn or c.part.l2_description
            grouped.setdefault(group_key, []).append(c)
        selected: List[PartCandidate] = []
        no_inventory: List[NoInventoryPart] = []
        rejected: List[PartCandidate] = []
        for _, group in grouped.items():
            available = [c for c in group if c.inventory_status == "有"]
            if not available:
                for c in group:
                    no_inventory.append(NoInventoryPart(part=c.part, features=c.features, reason="同型号组内无库存", suggestion=c.features.normalized_model))
                continue
            winner = sorted(available, key=lambda c: self._hdd_ssd_sort_key(c), reverse=True)[0]
            selected.append(winner)
            for c in group:
                if c is not winner:
                    rejected.append(c)
        return selected, no_inventory, rejected

    @staticmethod
    def _hdd_ssd_sort_key(candidate: PartCandidate) -> Tuple[int, float, int]:
        inventory_score = 1 if candidate.inventory_status == "有" else 0
        capacity_score = candidate.features.capacity_value or 0.0
        pn_score = sum(ord(ch) for ch in candidate.part.pn)
        return inventory_score, capacity_score, pn_score

    def _select_nic(self, candidates: Sequence[PartCandidate]) -> Tuple[List[PartCandidate], List[NoInventoryPart], List[PartCandidate]]:
        grouped: Dict[Tuple[str, str], List[PartCandidate]] = {}
        for c in candidates:
            vendor = c.features.normalized_vendor or "Unknown"
            fw_key = c.features.nic_fw_package_key or c.part.fw_raw or "UNKNOWN_FW_PACKAGE"
            grouped.setdefault((vendor, fw_key), []).append(c)
        selected: List[PartCandidate] = []
        no_inventory: List[NoInventoryPart] = []
        rejected: List[PartCandidate] = []
        for _, group in grouped.items():
            available = [c for c in group if c.inventory_status == "有"]
            if not available:
                for c in group:
                    no_inventory.append(NoInventoryPart(part=c.part, features=c.features, reason="同厂商同 FW 包组内无库存", suggestion=c.features.normalized_model))
                continue
            winner = sorted(available, key=lambda c: self._nic_sort_key(c), reverse=True)[0]
            selected.append(winner)
            for c in group:
                if c is not winner:
                    rejected.append(c)
        return selected, no_inventory, rejected

    @staticmethod
    def _nic_sort_key(candidate: PartCandidate) -> Tuple[int, int, int, int, int]:
        inventory_score = 1 if candidate.inventory_status == "有" else 0
        port_score = candidate.features.nic_port_count or 0
        speed_score = candidate.features.nic_speed_gbps or 0
        generation_score = candidate.features.nic_generation_rank or 0
        pn_score = sum(ord(ch) for ch in candidate.part.pn)
        return inventory_score, port_score, speed_score, generation_score, pn_score

    def _select_raid(self, candidates: Sequence[PartCandidate]) -> Tuple[List[PartCandidate], List[NoInventoryPart], List[PartCandidate]]:
        grouped: Dict[Tuple[str, str], List[PartCandidate]] = {}
        for c in candidates:
            series = c.features.raid_series or "UNKNOWN_SERIES"
            spec = c.features.raid_spec or "UNKNOWN_SPEC"
            grouped.setdefault((series, spec), []).append(c)
        selected: List[PartCandidate] = []
        no_inventory: List[NoInventoryPart] = []
        rejected: List[PartCandidate] = []
        for _, group in grouped.items():
            available = [c for c in group if c.inventory_status == "有"]
            if not available:
                for c in group:
                    no_inventory.append(NoInventoryPart(part=c.part, features=c.features, reason="同系列同规格组内无库存", suggestion=f"{c.features.raid_series or ''} {c.features.raid_spec or ''}".strip() or c.features.normalized_model))
                continue
            winner = sorted(available, key=lambda c: self._raid_sort_key(c), reverse=True)[0]
            selected.append(winner)
            for c in group:
                if c is not winner:
                    rejected.append(c)
        return selected, no_inventory, rejected

    @staticmethod
    def _raid_sort_key(candidate: PartCandidate) -> Tuple[int, int]:
        inventory_score = 1 if candidate.inventory_status == "有" else 0
        pn_score = sum(ord(ch) for ch in candidate.part.pn)
        return inventory_score, pn_score
